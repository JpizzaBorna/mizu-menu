// Address of the menu server (saved menu + admin). Empty = same site (/api).
window.MIZU_API = 'https://iswslfdaeoaxgithwezm.supabase.co/functions/v1/api'
